package mx.edu.utez.login4a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)



        val chkPeluche = findViewById<CheckBox>(R.id.chkPeluche)
        val rgGroup = findViewById<RadioGroup>(R.id.rgGroup)
        val rgPequeno = findViewById<RadioButton>(R.id.rgPequeno)
        val rgGrande = findViewById<RadioButton>(R.id.rgGrande)
        val btnOrdenar = findViewById<Button>(R.id.btnOrdenar)






    }
}