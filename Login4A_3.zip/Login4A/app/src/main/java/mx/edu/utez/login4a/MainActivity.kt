package mx.edu.utez.login4a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_linear)   ///AQUI PONES EL NOMBRE DEL LAYOUT QUE QUIERES QUE EMULE


        val edtUsuario = findViewById<EditText>(R.id.edtUsuario)
        val edtContra = findViewById<EditText>(R.id.edtContra)

        ///R. guarda el registro de los recursos de tu aplicacion

        val btnIniciar = findViewById<Button>(R.id.btnIniciar)
        val btnOlvidar = findViewById<Button>(R.id.btnOlvidaste)


        //R. y puedes poner cualquiera de estos
        ///drawable/// id ////  string   //// layout



        ///function suma (x,y){
        // return x + y;
        // }


        //const suma = (x,y) => {
        // return x + y;
        //}

        //los dos hacen lo  mismo
        ///Funcion landa

        btnIniciar .setOnClickListener {
            ///Clase para abrir componentes nuevos
            //Intent <<< 1.origen,2.Destino
            //Intent intent = new Intent();

            val intent = Intent(this@MainActivity,
            Home::class.java);
            startActivity(intent)

            /*edtUsuario.setText("Hola Mundo!!!")

            ///Cambiar texto en boton
            btnOlvidar.text = "Otro texto"
            println("Algooooooo")

            Toast.makeText(
                this@MainActivity,
                "entraste al boton",
                Toast.LENGTH_SHORT    ////ALERTA EN ANDROID(BURBUJA)
            ).show()
            */

        }

        Toast.makeText(
            this@MainActivity,
            "Texto de ejemplo",
            Toast.LENGTH_SHORT
        ).show()







    }
}