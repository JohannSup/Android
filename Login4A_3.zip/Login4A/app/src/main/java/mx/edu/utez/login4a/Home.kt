package mx.edu.utez.login4a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)



        val chkPeluche = findViewById<CheckBox>(R.id.chkPeluche)
        val rgGroup = findViewById<RadioGroup>(R.id.rgGroup)
        val rgPequeno = findViewById<RadioButton>(R.id.rgPequeno)
        val rgGrande = findViewById<RadioButton>(R.id.rgGrande)
        val btnOrdenar = findViewById<Button>(R.id.btnOrdenar)

        btnOrdenar.setOnClickListener {
            val valorCheck = chkPeluche.isChecked()
            println( valorCheck.toString())
            //cuando marques el boton Es un peluche  hara un true o false
            val valorGroup = rgGroup.checkedRadioButtonId
            when(valorGroup){
                //Verifica si el grupo esta marcado
              //  R.id.rgGrande -> println("Grande")
                //R.id.rgPequeno -> println("Pequeño")
                //DEPENDIENDO DEL IDIOMA SE IMPRIMIRA EN CONSOLA
                R.id.rgGrande -> println(resources.getString(R.string.str_Grande))
                R.id.rgPequeno -> println(resources.getString(R.string.str_Pequeno))
            }

        }

        //Verificar un boton individual
        //resources.getString(R.string.str_Grande)
       // val valorRadioInicial = rgGrande.isChecked




    }
}